#!/bin/env python
"""Start the bot."""
from archivebot.archivebot import main

main()
